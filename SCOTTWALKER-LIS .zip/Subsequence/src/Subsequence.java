import java.security.SecureRandom;//random # generator class
import java.util.Arrays; 

public class Subsequence {
// creating array to take in min & max range 
	static int[] randomNumbers(int min, int max) {
		int x = max - min + 1; // # of integers needed to generate
		
		//Creating array to store numbers in [from,to]
		int a[] = new int[x];
		for (int i=0; i<x; i++)
		{a[i] =i;}
			
	//array that stores the result
	int[] result = new int[x];
	
	int s = x;
SecureRandom rd = new SecureRandom();
for (int i=0; i<x; i++) {
	int k = rd.nextInt(x);

result[i] = a[k];
	
	a[k] = a[s-1];

	x--;}
return result;
}
	//MAIN
	public static void main(String[] args) {
		int[] result = randomNumbers(1,100);
		for(int i=0;i<result.length;i++)
				System.out.println(result[i] + " ");
	}
class Solution extends Subsequence { // new class to use the random number array and find LIS
	public int lengthOfLIS(int[] nums) {
		if (nums == null || nums.length == 0)
			return 0;
		int[] dp = new int[nums.length];
		int len =0;
		for (int num : nums) {
			int index = Arrays.binarySearch(dp, 0, len, num); // look for # in dp array from position 0 to the length 
		if (index < 0)
			index = -(index+1);
		dp[index] = num;
		if (index ==len)
			++len;
		}
		return len;
	}
	}
	
	
}

